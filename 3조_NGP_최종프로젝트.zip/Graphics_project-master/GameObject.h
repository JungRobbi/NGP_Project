#pragma once
#include "stdafx.h"
#include <gl/glew.h>
#include <string>
#include "Scene.h"
#include "Component.h"
#include "Collide.h"

enum E_LIFE_TYPE { E_LIFE_LIVE, E_LIFE_REMAIN, E_LIFE_DEAD };

class GameObject
{
	std::list<Component*> components;

public:
	E_LIFE_TYPE lifeState{ E_LIFE_LIVE };

	unsigned int modelLocation;

	int num_index;
	int obj_num=-1;
	int obj_kind = 0;

	GLint VAO;
	GLint texture;

	std::list<int> Item_bag;

public:
	GameObject();
	virtual ~GameObject() {} // �Ҹ��� �����ؾ���

	E_LIFE_TYPE getLifeState() const { return lifeState; }
	void setLifeState(E_LIFE_TYPE state) { lifeState = state; }

	virtual void start()
	{
		for (auto component : components)
			component->start();
	}

	virtual void update()
	{
		for (auto component : components)
			component->update();
	}
	virtual void render();

	template<typename T>
	T* AddComponent();

	template<typename T>
	T* GetComponent()
	{
		for (auto component : components)
		{
			auto c = dynamic_cast<T*>(component);
			if (c) return c;
		}
		return nullptr;
	}
};

template<typename T>
T* GameObject::AddComponent()
{
	auto component = new T;
	component->gameObject = this;
	components.push_back(component);
	return component;
}
