#include "PlayerJump.h"


void PlayerJump::start()
{

}

void PlayerJump::update()
{
}