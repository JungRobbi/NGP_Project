#pragma once
#include <gl/glew.h>

class Texture
{
public:
	static GLuint texture[20];
};

