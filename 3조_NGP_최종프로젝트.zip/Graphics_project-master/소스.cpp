﻿#define  _CRT_SECURE_NO_WARNINGS
#define STB_IMAGE_IMPLEMENTATION

#define SERVERPORT 9000
#define BUFSIZE    50

#include <vector>
#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <time.h>
#include <stdlib.h>
#include <cmath>
#include <cctype>
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <random>
#include <algorithm>

#include "stdafx.h"

#include "Scene.h"

#include "stb_image.h"
#include "shader.h"
#include "objRead.h"

#include "Mmsystem.h"
#include "Digitalv.h"

#include "VAO.h"
#include "GameScene.h"
#include "PlayerJump.h"

#include "Input.h"
#include "DestroyEffect.h"

#include "Common.h"

#include "MSGFunc.h"
#include "PlayerInfoLobbyFunc.h"
#include "PlayerInforSceneFunc.h"
#include "AddBlock.h"
#include "CollideInfo.h"
#include "OtherPlayer.h"
#include "PlayerLeave.h"
#include "Pause.h"

CRITICAL_SECTION cs;

char* SERVERIP;
std::string m_Name;

MCI_OPEN_PARMS m_mciOpenParms;
MCI_PLAY_PARMS m_mciPlayParms;
DWORD m_dwDeviceID;
MCI_OPEN_PARMS mciOpen;
MCI_PLAY_PARMS mciPlay;

int dwID;
bool b_playgame = false;

using namespace std;

uniform_real_distribution<float> uid(-3.5, 3.5);

GLuint g_window_w = 800;
GLuint g_window_h = 800;

GLuint VAO[100];
GLuint VBO_position[100];
GLuint VBO_normal[100];
GLuint VBO_uv[100];

int polygon_mode = 2;

void keyboard(unsigned char, int, int);
void keyboard2(unsigned char key2, int x, int y);
void Mouse(int button, int state, int x, int y);
void Motion(int x, int y);
void Motion2(int x, int y);
void TimerFunction(int value);
void Display();
void Display_Sub1();
void Display_Sub_Axe1();
void Display_Sub_Axe2();
void Display_Sub_Axe3();
void Display_Sub_Shoe1();
void Display_Sub_Shoe2();
void Display_Sub_Lobby();

void Reshape(int w, int h);
void InitBuffer();
void InitTexture();
void TimerFunction(int value);

void InitBuffer_bind(const int);


// obj 읽기 변수

int loadObj(const char* filename);
int loadObj_normalize_center_3f(const char* filename);
int loadObj_normalize_center_4f(const char* filename);
float* sphere_object;
int num_shape_list[10];
int num_vertices = 3;


float sunSize;
int shape = 1;					// 불러올 모양 (1. 육면체, 2. 구)

ObjRoad obj;

// 텍스쳐 변수

int img = 7;
GLuint texture[40];
int n_model = 0;
int n_max_model = 4;
int widthImage, heightImage, numberOfChannel = 0;

// 게임 변수
int num_ob = 6;//10;

int game = 0;					// 게임 state

int intmpx = 0;
int intmpy = 0;

float mousex = 0;				// 마우스 x
float mousey = 0;				// 마우스 y

float create_height = 8.0f;

float f_Light_ambients[3];

BoundingBox BoundBox[10];

glm::mat4 TR = glm::mat4(1.0f);

bool key[256];
float msx, msy = 0;
bool start = false;

std::list<Scene*> sc;

int Pcolor;
bool b_PauseEnable = false;

SOCKET sock;
GameData* RecvData;
GAMEMSG recv_msg;

void SceneChange(int num_scene);
void ResetChange();
void NestSceneChange();

std::list<GameData*> MsgCommandQueue; // 메세지 큐

DWORD WINAPI RecvThread(LPVOID temp);

DWORD WINAPI ConnectServer(LPVOID temp) {
	int retval;

	// 윈속 초기화
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;

	std::cout << std::endl << " ======== Login ======== " << std::endl << std::endl;
	while (true) {
		std::cout << std::endl << "사용 할 닉네임을 입력해주세요. (10자 이내) : ";
		std::cin >> m_Name;
		if (m_Name.size() > 10)
			std::cout << "닉네임은 영문 10자 이상으로 할 수 없습니다." << std::endl;
		else
			break;
	}
	std::cout << std::endl << "접속 할 서버주소를 입력해주세요(ex 197.xxx.xxx.xxx) : ";
	std::string server_s;
	std::cin >> server_s;
	Vector3 color{ 0, 0, 0 };
	std::cout << std::endl << "사용 할 색상을 입력해주세요 ( float 3개 ) : ";
	std::cin >> color.x >> color.y >> color.z;
	

	SERVERIP = new char[server_s.size() + 1];
	SERVERIP[server_s.size()] = '\0';
	strcpy(SERVERIP, server_s.c_str());

	// 소켓 생성
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == INVALID_SOCKET) err_quit("socket()");

	// connect()

	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	inet_pton(AF_INET, SERVERIP, &serveraddr.sin_addr);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = connect(sock, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) err_quit("connect()");

	HANDLE hThread;

	hThread = CreateThread(NULL, 0, RecvThread, (LPVOID)sock, 0, NULL);
	CloseHandle(hThread);

	PlayerInfoLobby info{ MSG_PLAYER_INFO_LOBBY, (char*)m_Name.c_str(), color };
	std::cout << std::endl << " 접속 완료 " << std::endl;
	retval = sendPlayerInfoLobby(sock, info);

	return 0;
}

int main(int argc, char** argv)
{

	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;

	InitializeCriticalSection(&cs);
	// create window using freeglut
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(g_window_w, g_window_h);
	glutInitWindowPosition(0, 0);

	glutCreateWindow("Computer Graphics");

	HANDLE hThread;

	hThread = CreateThread(NULL, 0, ConnectServer, NULL, 0, NULL);
	CloseHandle(hThread);

	//////////////////////////////////////////////////////////////////////////////////////
	//// initialize GLEW
	//////////////////////////////////////////////////////////////////////////////////////
	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK)
	{
		std::cerr << "Unable to initialize GLEW ... exiting" << std::endl;
		exit(EXIT_FAILURE);
	}

	//////////////////////////////////////////////////////////////////////////////////////
	//// Create shader program an register the shader
	//////////////////////////////////////////////////////////////////////////////////////

	GLuint vShader[4];
	GLuint fShader[4];

	vShader[0] = MakeVertexShader("vertex.glvs", 0);
	fShader[0] = MakeFragmentShader("fragment.glfs", 0);

	// shader Program
	s_program[0] = glCreateProgram();
	glAttachShader(s_program[0], vShader[0]);
	glAttachShader(s_program[0], fShader[0]);
	glLinkProgram(s_program[0]);
	checkCompileErrors(s_program[0], "PROGRAM");

	{ // initialize
		for (int i{}; i < 3; ++i)
			f_Light_ambients[i] = 0.3f;

		InitBuffer();
		InitTexture();
		for (int i{}; i < num_ob; ++i) {
			InitBuffer_bind(i);
		}

		glEnable(GL_DEPTH_TEST);
		mciOpen.lpstrElementName = "Resource/bgm.mp3";
		mciOpen.lpstrDeviceType = "mpegvideo";

		mciSendCommand(NULL, MCI_OPEN, MCI_OPEN_ELEMENT | MCI_OPEN_TYPE,
			(DWORD)(LPVOID)&mciOpen);

		dwID = mciOpen.wDeviceID;

		mciSendCommand(dwID, MCI_PLAY, MCI_DGV_PLAY_REPEAT, (DWORD)(LPVOID)&m_mciPlayParms);
	}

	sc.emplace_back(new GameScene(0, num_shape_list, texture, VAO, s_program));


	// callback functions
	glutDisplayFunc(Display);
	glutReshapeFunc(Reshape);

	glutMouseFunc(Mouse);
	//glutMotionFunc(Motion);

	glutPassiveMotionFunc(Motion2);
	glutKeyboardFunc(keyboard);
	glutKeyboardUpFunc(keyboard2);
	glutTimerFunc(10, TimerFunction, 1);

	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);


	// freeglut 윈도우 이벤트 처리 시작. 윈도우가 닫힐때까지 후한루프 실행.
	glutMainLoop();
	DeleteCriticalSection(&cs);
	return 0;
}


void InitBuffer()
{
	//// 5.1. VAO 객체 생성 및 바인딩
	glGenVertexArrays(10, VAO);
	glGenBuffers(10, VBO_position);
	glGenBuffers(10, VBO_normal);
	glGenBuffers(10, VBO_uv);
}

void InitBuffer_bind(const int street) {
	BoundingBox* bb = nullptr;
	if (street == 0) {
		num_shape_list[Cube] = obj.loadObj_normalize_center_3f("Resource/cube.obj");
		bb = &BoundBox[Cube];
	}
	else if (street == 1) {
		num_shape_list[Star] = obj.loadObj_normalize_center_3f("Resource/Star.obj");
		bb = &BoundBox[Star];
	}
	else if (street == 2) {
		num_shape_list[Plane] = obj.loadObj_normalize_center_3f("Resource/plane.obj");
		bb = &BoundBox[Plane];
	}
	else if (street == 3) {
		num_shape_list[Pickaxe] = obj.loadObj_normalize_center_4f("Resource/Pickaxe.obj");
		bb = &BoundBox[Pickaxe];
	}
	else if (street == 4) {
		num_shape_list[Grass] = obj.loadObj_normalize_center_4f("Resource/grass.obj");
		bb = &BoundBox[Grass];
	}
	else if (street == 5) {
		num_shape_list[Shoes] = obj.loadObj_normalize_center_4f("Resource/Shoe.obj");
		bb = &BoundBox[Shoes];
	}
	/*else if (street == 6) {
		num_shape_list[Cannon] = obj.loadObj_normalize_center_4f("Resource/Cannon.obj");
		bb = &BoundBox[Cannon];
	}
	else if (street == 7) {
		num_shape_list[Ball] = obj.loadObj_normalize_center_3f("Resource/sphere.obj");
		bb = &BoundBox[Ball];
	}
	else if (street == 8) {
		return;
		num_shape_list[Book] = obj.loadObj_normalize_center_4f("Resource/cube.obj");
		bb = &BoundBox[Book];
	}
	else if (street == 9) {
		num_shape_list[Spike] = obj.loadObj_normalize_center_4f("Resource/spike.obj");
		bb = &BoundBox[Spike];
	}*/

	if (bb) {
		bb->maxX = obj.maxX;
		bb->minX = obj.minX;
		bb->maxY = obj.maxY;
		bb->minY = obj.minY;
		bb->maxZ = obj.maxZ;
		bb->minZ = obj.minZ;
	}

	glUseProgram(s_program[0]);
	glBindVertexArray(VAO[street]);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_position[street]);
	glBufferData(GL_ARRAY_BUFFER, obj.outvertex.size() * sizeof(glm::vec3), &obj.outvertex[0], GL_STATIC_DRAW);
	GLint pAttribute = glGetAttribLocation(s_program[0], "aPos");
	glVertexAttribPointer(pAttribute, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), 0);
	glEnableVertexAttribArray(pAttribute);

	glBindBuffer(GL_ARRAY_BUFFER, VBO_normal[street]);
	glBufferData(GL_ARRAY_BUFFER, obj.outnormal.size() * sizeof(glm::vec3), &obj.outnormal[0], GL_STATIC_DRAW);
	GLint nAttribute = glGetAttribLocation(s_program[0], "aNormal");
	glVertexAttribPointer(nAttribute, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), 0);
	glEnableVertexAttribArray(nAttribute);

	glBindBuffer(GL_ARRAY_BUFFER, VBO_uv[street]);
	glBufferData(GL_ARRAY_BUFFER, obj.outuv.size() * sizeof(glm::vec2), &obj.outuv[0], GL_STATIC_DRAW);
	GLint tAttribute = glGetAttribLocation(s_program[0], "aTex");
	glVertexAttribPointer(tAttribute, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), 0);
	glEnableVertexAttribArray(tAttribute);

	obj.outvertex = std::vector< glm::vec3 >(0.0f);  // 다음 obj 불러오기 위한 초기화
	obj.outnormal = std::vector< glm::vec3 >(0.0f);
	obj.outuv = std::vector< glm::vec2 >(0.0f);

	obj.vertexIndices = std::vector< unsigned int >(0.0f);
	obj.uvIndices = std::vector< unsigned int >(0.0f);
	obj.normalIndices = std::vector< unsigned int >(0.0f);
	obj.temp_vertices = std::vector< glm::vec3 >(0.0f);
	obj.temp_uvs = std::vector< glm::vec2 >(0.0f);
	obj.temp_normals = std::vector< glm::vec3 >(0.0f);
}


void InitTexture()
{	
	BITMAPINFO* bmp;
	string map[40] = { "Resource/main.png","Resource/B.png","Resource/gold.png","Resource/123.png","Resource/321.png","Resource/grass.png",
		"Resource/face.png","Resource/sand.png", "Resource/skybox2_top.png", "Resource/skybox2_left.png", "Resource/skybox2_front.png", "Resource/skybox2_right.png",
		"Resource/skybox2_back.png", "Resource/skybox2_bottom.png", "Resource/vinus.png", "Resource/mars.png", "Resource/jupiter.png", "Resource/magma2.png", "Resource/sun.png","Resource/xxx.png",
		"Resource/green.png", "Resource/yellow.png","Resource/skybox3_top.png", "Resource/skybox3_left.png", "Resource/skybox3_front.png", "Resource/skybox3_right.png",
		"Resource/skybox3_back.png", "Resource/skybox3_bottom.png", "Resource/Item.png","Resource/GameClear.png","Resource/axe.png","Resource/shoe.png","Resource/Robby.png",
		"Resource/slime.png" };
																			
	glGenTextures(40, texture); //--- 텍스처 생성

	for (int i = 0; i < 40; ++i) {
		glBindTexture(GL_TEXTURE_2D, texture[i]); //--- 텍스처 바인딩
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT); //--- 현재 바인딩된 텍스처의 파라미터 설정하기
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		stbi_set_flip_vertically_on_load(true);
		unsigned char* data = stbi_load(map[i].c_str(), &widthImage, &heightImage, &numberOfChannel, 0);//--- 텍스처로 사용할 비트맵 이미지 로드하기
		glTexImage2D(GL_TEXTURE_2D, 0, 3, widthImage, heightImage, 0, GL_RGBA, GL_UNSIGNED_BYTE, data); //---텍스처 이미지 정의
		stbi_image_free(data);
	}

	glUseProgram(s_program[0]);
	int tLocation = glGetUniformLocation(s_program[0], "outTex"); //--- outTexture 유니폼 샘플러의 위치를 가져옴
	glUniform1i(tLocation, 0); //--- 샘플러를 0번 유닛으로 설정
}

void Display()
{
	//*************************************************************************
	// 출력 설정
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	if (Scene::scene->p_player->GetComponent<Camera>()->state != FIRST_VIEW)
		ShowCursor(true);
	else {
		ShowCursor(false);
	}
	ShowCursor(false);

	//*************************************************************************
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	//*************************************************************************
	// 조명 설정


	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 10.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 1.0, 1.0, 1.0);
	int lighAmbientLocation = glGetUniformLocation(s_program[0], "lightAmbient"); //--- lightAmbient 
	glUniform3f(lighAmbientLocation, f_Light_ambients[0], f_Light_ambients[1], f_Light_ambients[2]);
	Pcolor = glGetUniformLocation(s_program[0], "color"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform4f(Pcolor, 0.0, 0.0, 0.0, 0.0);

	//*************************************************************************
	// 그리기 부분

	glUseProgram(s_program[0]);

	glViewport(0, 0, WINDOWX, WINDOWY);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_CULL_FACE);

	if (!sc.empty()) {
		Scene::scene->update();
		Scene::scene->render();
	}

	if (Scene::scene->p_player->GetComponent<Camera>()->state == TOP_VIEW) {
		auto p = find(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Cube);
		if (p != Scene::scene->p_player->Item_bag.end()) {
			if (n_model == Cube) {
				glBindVertexArray(VAO[Cube]);
				TR = glm::mat4(1.0f);
				TR = glm::translate(TR, glm::vec3(msx * 15.0f, create_height, -msy * 15.0f));
				TR = glm::scale(TR, glm::vec3(0.4f, 0.4f, 0.4f));
				glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
				glBindTexture(GL_TEXTURE_2D, texture[4]);
				glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Cube]);
			}
		}

		glBindVertexArray(VAO[Cube]);
		TR = glm::mat4(1.0f);
		TR = glm::translate(TR, Scene::scene->p_player->GetComponent<Transform3D>()->position);
		TR = glm::scale(TR, glm::vec3(0.4f, 0.4f, 0.4f));
		glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
		glBindTexture(GL_TEXTURE_2D, texture[20]);
		glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Cube]);
	}

	/*glBindVertexArray(VAO[3]);
	TR = glm::mat4(1.0f);
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	glBindTexture(GL_TEXTURE_2D, texture[1]);
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[3]);*/

	if (Scene::scene->n_scene == 0) {
		Display_Sub_Lobby();
	}
	if (f_Light_ambients[0] < 0.3f || Scene::scene->n_scene == 7) {
		Display_Sub1();
	}
	auto p = count(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Pickaxe);
	if (p > 0) {
		Display_Sub_Axe1();
	}
	if (p > 1) {
		Display_Sub_Axe2();
	}
	if (p > 2) {
		Display_Sub_Axe3();
	}
	auto o = count(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Shoes);
	if (o > 0) {
		Display_Sub_Shoe1();
	}
	if (o > 1) {
		Display_Sub_Shoe2();
	}
	if (Scene::scene->n_scene == 2) {
		if (Scene::scene->p_player->GetComponent<Transform3D>()->position.y <= 0.8) {
			Scene::scene->p_player->GetComponent<Transform3D>()->position = glm::vec3(0.0f, 3.0f, 0.0f);
			Scene::scene->p_player->GetComponent<Transform3D>()->scale = glm::vec3(1.0f, 1.0f, 1.0f);
			Scene::scene->p_player->GetComponent<Transform3D>()->direction = glm::vec3(0.0f, 0.0f, -1.0f);
		}
	}



	glDisable(GL_CULL_FACE);
	glDisable(GL_BLEND); // 블렌딩 해제

	if (Scene::scene->n_scene == 0 && b_playgame) {
		NestSceneChange();
		b_playgame = false;
	}

	glutSwapBuffers();
}

void Display_Sub_Lobby()
{
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	unsigned int viewLocation = glGetUniformLocation(s_program[0], "view");
	unsigned int projLocation = glGetUniformLocation(s_program[0], "projection");

	glm::mat4 Vw = glm::mat4(1.0f);
	glm::mat4 Pj = glm::mat4(1.0f);
	Vw = glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	Pj = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.00f);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &Vw[0][0]);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &Pj[0][0]);

	//*************************************************************************
	// 조명 설정
	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 0.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 0.8, 0.8, 0.8);
	//*************************************************************************
	// 그리기 부분
	glViewport(0, 0, 800, 800);
	glBindTexture(GL_TEXTURE_2D, texture[32]);
	glBindVertexArray(VAO[Plane]);
	TR = glm::mat4(1.0f);
	TR = glm::translate(TR, glm::vec3(0.0f, 0.0f, -3.0f));
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Plane]);


}

void Display_Sub1()
{
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	unsigned int viewLocation = glGetUniformLocation(s_program[0], "view");
	unsigned int projLocation = glGetUniformLocation(s_program[0], "projection");

	glm::mat4 Vw = glm::mat4(1.0f);
	glm::mat4 Pj = glm::mat4(1.0f);
	Vw = glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	Pj = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.00f);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &Vw[0][0]);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &Pj[0][0]);

	//*************************************************************************
	// 조명 설정
	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 0.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 1.0, 1.0, 1.0);
	//*************************************************************************
	// 그리기 부분
	glViewport(100, 400, 600, 300);

	glBindVertexArray(VAO[Plane]);
	TR = glm::mat4(1.0f);
	TR = glm::translate(TR, glm::vec3(0.0f, 0.0f, -3.0f));
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	if (Scene::scene->n_scene == 7) {
		glBindTexture(GL_TEXTURE_2D, texture[29]);
	}
	else {
		glBindTexture(GL_TEXTURE_2D, texture[28]);
	}
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Plane]);

	

}
void Display_Sub_Axe1()
{
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	unsigned int viewLocation = glGetUniformLocation(s_program[0], "view");
	unsigned int projLocation = glGetUniformLocation(s_program[0], "projection");

	glm::mat4 Vw = glm::mat4(1.0f);
	glm::mat4 Pj = glm::mat4(1.0f);
	Vw = glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	Pj = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.00f);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &Vw[0][0]);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &Pj[0][0]);

	//*************************************************************************
	// 조명 설정
	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 0.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 1.0, 1.0, 1.0);
	//*************************************************************************
	// 그리기 부분
	glViewport(720, 720, 80, 80);
	glBindTexture(GL_TEXTURE_2D, texture[30]);
	glBindVertexArray(VAO[Plane]);
	TR = glm::mat4(1.0f);
	TR = glm::translate(TR, glm::vec3(0.0f, 0.0f, -3.0f));
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Plane]);


}

void Display_Sub_Axe2()
{
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	unsigned int viewLocation = glGetUniformLocation(s_program[0], "view");
	unsigned int projLocation = glGetUniformLocation(s_program[0], "projection");

	glm::mat4 Vw = glm::mat4(1.0f);
	glm::mat4 Pj = glm::mat4(1.0f);
	Vw = glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	Pj = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.00f);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &Vw[0][0]);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &Pj[0][0]);

	//*************************************************************************
	// 조명 설정
	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 0.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 1.0, 1.0, 1.0);
	//*************************************************************************
	// 그리기 부분
	glViewport(640, 720, 80, 80);
	glBindTexture(GL_TEXTURE_2D, texture[30]);
	glBindVertexArray(VAO[Plane]);
	TR = glm::mat4(1.0f);
	TR = glm::translate(TR, glm::vec3(0.0f, 0.0f, -3.0f));
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Plane]);


}
void Display_Sub_Axe3()
{
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	unsigned int viewLocation = glGetUniformLocation(s_program[0], "view");
	unsigned int projLocation = glGetUniformLocation(s_program[0], "projection");

	glm::mat4 Vw = glm::mat4(1.0f);
	glm::mat4 Pj = glm::mat4(1.0f);
	Vw = glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	Pj = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.00f);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &Vw[0][0]);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &Pj[0][0]);

	//*************************************************************************
	// 조명 설정
	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 0.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 1.0, 1.0, 1.0);
	//*************************************************************************
	// 그리기 부분
	glViewport(560, 720, 80, 80);
	glBindTexture(GL_TEXTURE_2D, texture[30]);
	glBindVertexArray(VAO[Plane]);
	TR = glm::mat4(1.0f);
	TR = glm::translate(TR, glm::vec3(0.0f, 0.0f, -3.0f));
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Plane]);


}
void Display_Sub_Shoe1()
{
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	unsigned int viewLocation = glGetUniformLocation(s_program[0], "view");
	unsigned int projLocation = glGetUniformLocation(s_program[0], "projection");

	glm::mat4 Vw = glm::mat4(1.0f);
	glm::mat4 Pj = glm::mat4(1.0f);
	Vw = glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	Pj = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.00f);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &Vw[0][0]);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &Pj[0][0]);

	//*************************************************************************
	// 조명 설정
	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 0.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 1.0, 1.0, 1.0);
	//*************************************************************************
	// 그리기 부분
	glViewport(720, 640, 80, 80);
	glBindTexture(GL_TEXTURE_2D, texture[31]);
	glBindVertexArray(VAO[Plane]);
	TR = glm::mat4(1.0f);
	TR = glm::translate(TR, glm::vec3(0.0f, 0.0f, -3.0f));
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Plane]);


}
void Display_Sub_Shoe2()
{
	// 카메라 설정
	unsigned int modelLocation = glGetUniformLocation(s_program[0], "model");
	unsigned int viewLocation = glGetUniformLocation(s_program[0], "view");
	unsigned int projLocation = glGetUniformLocation(s_program[0], "projection");

	glm::mat4 Vw = glm::mat4(1.0f);
	glm::mat4 Pj = glm::mat4(1.0f);
	Vw = glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	Pj = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.00f);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &Vw[0][0]);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &Pj[0][0]);

	//*************************************************************************
	// 조명 설정
	int lightPosLocation = glGetUniformLocation(s_program[0], "lightPos"); //--- lightPos 값 전달: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, 0.0, 0.0, 0.0);
	int lightColorLocation = glGetUniformLocation(s_program[0], "lightColor"); //--- lightColor 값 전달: (1.0, 1.0, 1.0) 백색
	glUniform3f(lightColorLocation, 1.0, 1.0, 1.0);
	//*************************************************************************
	// 그리기 부분
	glViewport(640, 640, 80, 80);
	glBindTexture(GL_TEXTURE_2D, texture[31]);
	glBindVertexArray(VAO[Plane]);
	TR = glm::mat4(1.0f);
	TR = glm::translate(TR, glm::vec3(0.0f, 0.0f, -3.0f));
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(TR));
	glDrawArrays(GL_TRIANGLES, 0, num_shape_list[Plane]);


}


void Reshape(int w, int h)
{
	g_window_w = w;
	g_window_h = h;
	glViewport(0, 0, w, h);
}

void Mouse(int button, int state, int x, int y)
{
	if (b_PauseEnable)
		return;

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && Scene::scene->p_player->GetComponent<Camera>()->state == TOP_VIEW) {
		if (n_model == Cube) {
			auto p = find(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Cube);
			if (p != Scene::scene->p_player->Item_bag.end()) {
				AddBlock ab = { MSG_ADD_BLOCK, Vector3{msx * 15.0f,8.0,-msy * 15.0f} };
				sendAddBlock(sock, ab);
				Scene::scene->p_player->Item_bag.erase(p);
			}
		}
		else if (n_model == Star) {
			/*auto star = CreateStar(index_list, tex, vao);

			star->GetComponent<Transform3D>()->position = glm::vec3(0.0f, 5.5f, 0.0f);
			star->GetComponent<Transform3D>()->scale = glm::vec3(1.0f, 0.3f, 1.0f);
			star->GetComponent<Transform3D>()->direction = glm::vec3(0.0f, 1.0f, 0.0f);
			star->GetComponent<Transform3D>()->roll = 90.0f;*/
		} 
	}
	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP && Scene::scene->p_player->GetComponent<Camera>()->state == TOP_VIEW) {

	}
}
void Motion(int x, int y)
{

}

void Motion2(int x, int y)
{
	if (b_PauseEnable)
		return;

	if (Scene::scene->p_player->GetComponent<Camera>()->state == TOP_VIEW) {
		msx = ((float)x - ((float)WINDOWX / (float)2)) / ((float)WINDOWX / (float)2);
		msy = -((float)y - ((float)WINDOWY / (float)2)) / ((float)WINDOWY / (float)2);
	}
	if (Scene::scene->p_player->GetComponent<Camera>()->state == FIRST_VIEW) {
		if (x > WINDOWX  - 100 || x < 100 || y > WINDOWY - 100 || y < 100) {
			 SetCursorPos(WINDOWX / 2, WINDOWY / 2);
		}

		float xoffset = x - intmpx;
		float yoffset = intmpy - y;
		intmpx = x;
		intmpy = y;

		if (abs(xoffset) < WINDOWX / 4 && abs(yoffset) < WINDOWX / 4) {

			xoffset *= 0.2;
			yoffset *= 0.2;
		
			Scene::scene->p_player->GetComponent<Camera>()->fpsy += xoffset;
			Scene::scene->p_player->GetComponent<Camera>()->fpsup += yoffset;


			if (Scene::scene->p_player->GetComponent<Camera>()->fpsup > 70.0f)
				Scene::scene->p_player->GetComponent<Camera>()->fpsup = 70.0f;
			if (Scene::scene->p_player->GetComponent<Camera>()->fpsup < -70.0f)
				Scene::scene->p_player->GetComponent<Camera>()->fpsup = -70.0f;

		}
	}
}

void keyboard(unsigned char key2, int x, int y) {
	key[key2] = true;
	
	if (key2 == 27) {
		exit(0);
	}

	switch (key2) {
	case ';':
		NestSceneChange();
		break;
	case 'r':
		if (Scene::scene->p_player->GetComponent<Camera>()->state == FIRST_TO_TOP ||
			Scene::scene->p_player->GetComponent<Camera>()->state == FIRST_VIEW)
			Scene::scene->p_player->GetComponent<Camera>()->state = FIRST_TO_TOP;
		else
			Scene::scene->p_player->GetComponent<Camera>()->state = TOP_TO_FIRST;
		break;

	case '3':
		NestSceneChange();
		break;
	case '.':
		ResetChange();
		break;
	case 'q': 
		if (f_Light_ambients[0] < 0.3f) {
			for (int i{}; i < 3; ++i)
				f_Light_ambients[i] = 0.3f;
		}
		else {
			for (int i{}; i < 3; ++i)
				f_Light_ambients[i] = 0.1f;
		}
		break;
	case 'p':
		if (b_PauseEnable)
			b_PauseEnable = false;
		else
			b_PauseEnable = true;
		sendPause(sock, Pause{ MSG_PAUSE, b_PauseEnable });
		break;
	case VK_SPACE:
		if (Scene::scene->n_scene == 3)
			break;

		if (Scene::scene->p_player->GetComponent<PlayerJump>() &&
			Scene::scene->p_player->GetComponent<PlayerJump>()->jumping == false) {
			Scene::scene->p_player->GetComponent<Transform3D>()->velocity = Scene::scene->p_player->GetComponent<PlayerJump>()->jump_acceleration;
			Scene::scene->p_player->GetComponent<PlayerJump>()->jumping = true;
		}
		else {
			auto p = find(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Shoes);
			if (p != Scene::scene->p_player->Item_bag.end()) {
				Scene::scene->p_player->GetComponent<Transform3D>()->velocity = Scene::scene->p_player->GetComponent<PlayerJump>()->jump_acceleration;
				Scene::scene->p_player->Item_bag.erase(p);
			}
		}
		break;
	}

	glutPostRedisplay();
}
void keyboard2(unsigned char key2, int x, int y) {
	key[key2] = false;
	glutPostRedisplay();
}

void TimerFunction(int value) {

	if (!b_PauseEnable) {


		bool collide = false;

		if (Scene::scene->p_player->GetComponent<Camera>()->state == FIRST_VIEW) {
			if (key['a']) {						// 위로 이동
				Scene::scene->p_player->GetComponent<Transform3D>()->position.x += sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->position.z -= cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.x += sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.z -= cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;

			}
			if (key['d']) {						// 아래로 이동
				Scene::scene->p_player->GetComponent<Transform3D>()->position.x -= sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->position.z += cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.x -= sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.z += cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
			}
			if (key['s']) {						// 왼쪽으로 이동
				Scene::scene->p_player->GetComponent<Transform3D>()->position.x -= cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->position.z -= sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.x -= cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.z -= sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
			}
			if (key['w']) {						// 오른쪽으로 이동
				Scene::scene->p_player->GetComponent<Transform3D>()->position.x += cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->position.z += sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.x += cos((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
				Scene::scene->p_player->GetComponent<Transform3D>()->direction.z += sin((float)glm::radians(Scene::scene->p_player->GetComponent<Camera>()->fpsy)) * 0.04;
			}
		}
		else if (Scene::scene->p_player->GetComponent<Camera>()->state == TOP_VIEW) {
			if (key['a']) {						// 위로 이동
				Scene::scene->p_player->GetComponent<Camera>()->top_pos.x -= 0.1f;
				Scene::scene->p_player->GetComponent<Camera>()->top_dir.x -= 0.1f;
			}
			if (key['d']) {						// 아래로 이동
				Scene::scene->p_player->GetComponent<Camera>()->top_pos.x += 0.1f;
				Scene::scene->p_player->GetComponent<Camera>()->top_dir.x += 0.1f;
			}
			if (key['s']) {						// 왼쪽으로 이동
				Scene::scene->p_player->GetComponent<Camera>()->top_pos.z += 0.1f;
				Scene::scene->p_player->GetComponent<Camera>()->top_dir.z += 0.1f;
			}
			if (key['w']) {						// 오른쪽으로 이동
				Scene::scene->p_player->GetComponent<Camera>()->top_pos.z -= 0.1f;
				Scene::scene->p_player->GetComponent<Camera>()->top_dir.z -= 0.1f;
			}
		}

		{
			auto p = find(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Star);
			if (p != Scene::scene->p_player->Item_bag.end() && Scene::scene->n_scene != 6) {
				NestSceneChange();
			}
		}
		{
			auto p = find(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Spike);
			if (p != Scene::scene->p_player->Item_bag.end()) {
				ResetChange();
			}
		}
		{
			auto p = find(Scene::scene->p_player->Item_bag.begin(), Scene::scene->p_player->Item_bag.end(), Ball);
			if (p != Scene::scene->p_player->Item_bag.end()) {
				ResetChange();
			}
		}
	}

	glutPostRedisplay();

	glutTimerFunc(10, TimerFunction, 1);

}

void SceneChange(int num_scene)
{
	auto p = find_if(sc.begin(), sc.end(), [num_scene](const Scene* p_s) {
		return p_s->n_scene == num_scene;
		});

	if (p == sc.end()) {
		sc.emplace_back(new GameScene(num_scene, num_shape_list, texture, VAO, s_program));
	}
	else {
		(*p)->scene = (*p);
	}
}

void ResetChange()
{
	auto p = find(sc.begin(), sc.end(), Scene::scene);
	sc.emplace_back(new GameScene(Scene::scene->n_scene, num_shape_list, texture, VAO, s_program));
	sc.erase(p);
}

void NestSceneChange()
{
	auto p = find(sc.begin(), sc.end(), Scene::scene);
	if (Scene::scene->n_scene == 3) {
		Scene::scene->n_scene = 7;
		return;
	}
	else if (Scene::scene->n_scene == 7) {
		return;
	}

	auto gs = new GameScene(Scene::scene->n_scene + 1, num_shape_list, texture, VAO, s_program);

	strcpy(Scene::scene->Other1->GetComponent<OtherPlayer>()->ID, Scene::scene->ID[0]);
	strcpy(Scene::scene->Other2->GetComponent<OtherPlayer>()->ID, Scene::scene->ID[1]);
	Scene::scene->Other1->GetComponent<OtherPlayer>()->color = Scene::scene->color[0];
	Scene::scene->Other2->GetComponent<OtherPlayer>()->color = Scene::scene->color[1];

	sc.push_back(gs);
	
	sc.erase(p);
}

DWORD WINAPI RecvThread(LPVOID temp)
{
	while (true) {
		bool add_block = false;

		// 메세지 받기
		recv_msg = recvMSG(sock);

		EnterCriticalSection(&cs);
		auto msg = recv_msg;
		switch (msg) // 메세지 해석
		{
		case MSG_PLAYER_INFO_LOBBY:  // 데이터 받기
			RecvData = new PlayerInfoLobby{ recvPlayerInfoLobby(sock) };
			b_playgame = true;
			break;
		case MSG_PLAYER_INFO_SCENE:
			RecvData = new PlayerInfoScene{ recvPlayerInfoScene(sock) };
			break;
		case MSG_CHAT:
			break;
		case MSG_ADD_BLOCK:
			RecvData = new AddBlock{ recvAddBlock(sock) };
			break;
		case MSG_COLLIDE:
			RecvData = new S_Collide{ recvCollideInfo(sock) };
			break;
		case MSG_LEAVE:
			RecvData = new Leave{ recvPlayerLeave(sock) };
			std::cout << std::endl << " 플레이어가 게임을 종료 했습니다. ID - " << ((Leave*)RecvData)->GetID() << std::endl << std::endl;
			break;
		case MSG_GAMECLEAR:
			break;
		case MSG_PAUSE:
			RecvData = new Pause{ recvPause(sock) };
			b_PauseEnable = ((Pause*)RecvData)->GetPause();
			if (b_PauseEnable) {
				for (int i{}; i < 3; ++i)
					f_Light_ambients[i] = 0.05f;
				std::cout << std::endl << " 게임이 중지되었습니다. " << std::endl << std::endl;
			}
			else {
				for (int i{}; i < 3; ++i)
					f_Light_ambients[i] = 0.3f;
				std::cout << std::endl << " 게임이 재개되었습니다. " << std::endl << std::endl;
			}
			break;
		default:
			break;
		}

		if (msg == MSG_PLAYER_INFO_LOBBY) {  // 데이터 받기
			if (strcmp(((PlayerInfoLobby*)RecvData)->GetID(), (char*)m_Name.c_str()) != 0) {
				if (Scene::scene->othercheck == 0) {
					strcpy(Scene::scene->ID[0], ((PlayerInfoLobby*)RecvData)->GetID());
					Scene::scene->color[0] = glm::vec3(((PlayerInfoLobby*)RecvData)->GetReady().x, ((PlayerInfoLobby*)RecvData)->GetReady().y, ((PlayerInfoLobby*)RecvData)->GetReady().z);
				}
				else if (Scene::scene->othercheck == 1) {
					strcpy(Scene::scene->ID[1], ((PlayerInfoLobby*)RecvData)->GetID());
					Scene::scene->color[1] = glm::vec3(((PlayerInfoLobby*)RecvData)->GetReady().x, ((PlayerInfoLobby*)RecvData)->GetReady().y, ((PlayerInfoLobby*)RecvData)->GetReady().z);
				}
				Scene::scene->othercheck++;
			}
		}
		else if (msg == MSG_PLAYER_INFO_SCENE) {
			if (strcmp(Scene::scene->Other1->GetComponent<OtherPlayer>()->ID, ((PlayerInfoScene*)RecvData)->GetID()) == 0)
				Scene::scene->Other1->GetComponent<OtherPlayer>()->pos = glm::vec3(((PlayerInfoScene*)RecvData)->GetPos().x, ((PlayerInfoScene*)RecvData)->GetPos().y, ((PlayerInfoScene*)RecvData)->GetPos().z);
			if (strcmp(Scene::scene->Other2->GetComponent<OtherPlayer>()->ID, ((PlayerInfoScene*)RecvData)->GetID()) == 0)
				Scene::scene->Other2->GetComponent<OtherPlayer>()->pos = glm::vec3(((PlayerInfoScene*)RecvData)->GetPos().x, ((PlayerInfoScene*)RecvData)->GetPos().y, ((PlayerInfoScene*)RecvData)->GetPos().z);
		}
		else if (msg == MSG_CHAT) {

		}
		else if (msg == MSG_ADD_BLOCK) {
			add_block = true;
		}
		else if (msg == MSG_COLLIDE) {
			for (auto obj : Scene::scene->gameObjects)
			{
				if (obj->obj_num == ((S_Collide*)RecvData)->GetItem_index())
				{
					if (obj->VAO == Scene::scene->p_vao[Pickaxe])
					{
						Scene::scene->p_player->Item_bag.push_back(Pickaxe);
						Scene::scene->PushDelete(obj);
					}

					if (obj->VAO == Scene::scene->p_vao[Shoes])
					{
						Scene::scene->p_player->Item_bag.push_back(Shoes);
						Scene::scene->PushDelete(obj);
					}

					if (obj->VAO == Scene::scene->p_vao[Cube] && obj->GetComponent<DestroyEffect>())
					{
						obj->GetComponent<DestroyEffect>()->destroy = true;
						Scene::scene->p_player->Item_bag.push_back(Cube);
					}

					if (obj->VAO == Scene::scene->p_vao[Star])
					{
						Scene::scene->p_player->Item_bag.push_back(Star);
						Scene::scene->PushDelete(obj);
					}

				}
			}
		}

		if (add_block) {
			auto box = Scene::scene->CreateAirHardBox(num_shape_list, texture, VAO);
			box->AddComponent<Gravity>();
			box->GetComponent<Transform3D>()->position = glm::vec3(((AddBlock*)RecvData)->GetPosition().x, ((AddBlock*)RecvData)->GetPosition().y, ((AddBlock*)RecvData)->GetPosition().z);
			box->texture = texture[4];
			add_block = false;
		}

		LeaveCriticalSection(&cs);


		
	}

	// 소켓 닫기
	closesocket(sock);

	// 윈속 종료
	WSACleanup();

	return 0;
}