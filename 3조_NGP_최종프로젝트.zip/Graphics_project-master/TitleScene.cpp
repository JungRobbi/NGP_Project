#include "TitleScene.h"

TitleScene::TitleScene() : Scene()
{
	{
		auto title = CreateEmpty();
		//title->AddComponent<Transform3D>();
	}
}