#pragma once
#include "Component.h"
#include "Transform3D.h"
#include "GameObject.h"
#include "Input.h"

class PlayerMovement : public Component
{

public:
	void start() {}
	void update();
};

