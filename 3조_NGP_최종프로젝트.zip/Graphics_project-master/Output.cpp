#include "Output.h"

//char Output::screen[OUTPUT_HEIGHT][OUTPUT_WIDTH * 2 + 1];

void Output::render()
{

}