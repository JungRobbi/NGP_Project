#pragma once
#define WINDOWX 800
#define WINDOWY 800
#define pie 3.14159265358979324846

enum ShapeTag { Cube, Star, Plane, Pickaxe, Grass, Shoes, Cannon, Ball, Book, Spike };

#include <chrono>
#include <list>
#include <algorithm>
#include "GameData.h"
